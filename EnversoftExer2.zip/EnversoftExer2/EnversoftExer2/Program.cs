﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace EnversoftExer2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Data.csv"; 
            string outputNamesPath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Names.txt";
            string outputAddressPath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Address.txt";
            

            ReadTextFile(filePath, outputNamesPath, outputAddressPath);
        }

        public static void ReadTextFile(string path, string namesPath, string addressPath)
        {
            List<string> CompletedList = new List<string>();
            List<string> AllFirstNames = new List<string>();
            List<string> AllLastNames = new List<string>();
            List<string> ListAddress = new List<string>();

            var allLines = File.ReadAllLines(path);

            foreach (var record in allLines)
            {
                var values = record.Split(',');
                AllFirstNames.Add(values[0]);
                AllLastNames.Add(values[1]);
                ListAddress.Add(values[2]);
            }
            if (AllFirstNames[0] == "FirstName")
            {
                AllFirstNames.RemoveAt(0);
            }
            if (AllLastNames[0] == "LastName")
            {
                AllLastNames.RemoveAt(0);
            }
            if (ListAddress[0] == "Address")
            {
                ListAddress.RemoveAt(0);
            }

            CompletedList.AddRange(AllFirstNames);
            CompletedList.AddRange(AllLastNames); 
            CompletedList.Sort();

            ReadNames(CompletedList, namesPath);
            ReadAddress(ListAddress, addressPath);

            
        }

        public static void ReadNames(List<string> list, string outputPath)
        {
            List<string> namesList = new List<string>();
            foreach (var namelist in list.GroupBy(name => name).OrderByDescending(c => c.Count()))
            {
                using (TextWriter textWriter = new StreamWriter(outputPath, true))
                {
                    textWriter.WriteLine("{0} : {1}", namelist.Key, namelist.Count());
                    namesList.Add((namelist.Key).ToString());
                }
            }
        }

        public static void ReadAddress(List<string> list, string outputPath)
        {
            List<string> addressList = new List<string>();
            foreach (var addresslist in list.OrderBy(address => address.Split(' ').ElementAtOrDefault(1)))
            {
                using (TextWriter textWriter = new StreamWriter(outputPath, true))
                {
                    textWriter.WriteLine(addresslist);
                    addressList.Add(addresslist.ToString());
                }
            }
        }
    }
}
