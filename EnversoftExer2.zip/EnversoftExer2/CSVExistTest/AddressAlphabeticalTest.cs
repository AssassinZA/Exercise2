﻿namespace CSVExistTest
{
    public class AddressAlphabeticalTest
    {
        string addressListPath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\AddressTest.txt";
        string outputAddressPath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Address.txt";
        

        [SetUp]
        public void Setup()
        {
            File.WriteAllText(outputAddressPath, string.Empty);
        }

        [Test]
        public void IsAddressAlphabetical()
        {
            try
            {
                List<Addresses> tempList = new List<Addresses>();
                List<Addresses> placeholderList = new List<Addresses>();
                var addressList = addressListPath;
                Addresses address = new();

                if (File.Exists(outputAddressPath))
                {
                    string[] allLines = File.ReadAllLines(outputAddressPath);
                    foreach (var line in allLines)
                    { 
                        address.Address = line;
                        tempList.Add(address);
                    }

                    string[] placeHolder = File.ReadAllLines(addressListPath);
                    foreach (var line in placeHolder)
                    {
                        address.Address = line;
                        placeholderList.Add(address);
                    }

                    var expectedList = tempList.OrderByDescending(x => x.Address);
                    Assert.IsTrue(expectedList.SequenceEqual(placeholderList));
                }
                else
                {
                    Assert.Fail();
                }
        }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
}
    }
}
