﻿using System.Text.RegularExpressions;

namespace CSVExistTest
{
    public class CheckAddressFirstDigitsTest
    {
        
        string outputAddressPath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Address.txt";

        [SetUp]
        public void Setup()
        {
            File.WriteAllText(outputAddressPath, string.Empty);
            
        }

        [Test]
        public void CheckIfFirstCharIsNumberTest()
        {
            try
            {
                List<Addresses> tempList = new List<Addresses>();
                Addresses address = new();

                if (File.Exists(outputAddressPath))
                {
                    string[] allLines = File.ReadAllLines(outputAddressPath);
                    foreach (var line in allLines)
                    {
                        address.Address = line;
                        tempList.Add(address);
                    }
                    FilterList(tempList);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        public void FilterList(List<Addresses> list)
        {
            foreach (var item in list)
            {
                string address = item.Address;
                var firstElement = address.Substring(0, 1);
                bool isMatch = Regex.IsMatch(firstElement, @"\b(?<!\.)\d+(?!\.)\b");
                if (isMatch)
                {
                    Assert.IsTrue(isMatch);
                }
                else
                {
                    Assert.Fail();
                }
            }
        }
    }
}