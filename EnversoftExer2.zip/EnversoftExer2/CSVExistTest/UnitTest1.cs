using FluentAssertions;

namespace CSVExistTest
{
    public class CSVExistTest
    {
        string filePath = @"C:\Users\micha\source\repos\EnversoftExer2\EnversoftExer2\Files\Data.csv";
        


        [SetUp]
        public void Setup()
        {
            File.WriteAllText(filePath, string.Empty);
        }

        [Test]
        public void DoesCsvFileExist()
        {
            try
            {
                var pathExists = IsValidPath(filePath);
                pathExists.Should().BeTrue();

            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        private bool IsValidPath(string path, bool allowRelativePaths = false)
        {
            bool isValid;

            try
            {
                string fullPath = Path.GetFullPath(path);

                if (allowRelativePaths)
                {
                    isValid = Path.IsPathRooted(path);
                }
                else
                {
                    string root = Path.GetPathRoot(path);
                    isValid = string.IsNullOrEmpty(root.Trim(new char[] { '\\', '/' })) == false;
                }
            }
            catch (Exception ex)
            {
                isValid = false;
            }

            return isValid;
        }
    }
}